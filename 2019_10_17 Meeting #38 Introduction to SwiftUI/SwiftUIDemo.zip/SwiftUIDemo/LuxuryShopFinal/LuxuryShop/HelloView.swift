//
//  HelloView.swift
//  LuxuryShop
//
//  Created by michael.wang on 2019/10/12.
//  Copyright © 2019 Michael Wang. All rights reserved.
//

import SwiftUI

struct HelloView: View {
    @State private var name = ""
    
    var body: some View {
        VStack() {
            TextField("enter name here", text: $name)
                .font(.title)
                .padding()
            
            Text("Hello \(name)")
                .font(.title)
                .foregroundColor(.green)
        }
    }
}

struct HelloView_Previews: PreviewProvider {
    static var previews: some View {
        HelloView()
    }
}
