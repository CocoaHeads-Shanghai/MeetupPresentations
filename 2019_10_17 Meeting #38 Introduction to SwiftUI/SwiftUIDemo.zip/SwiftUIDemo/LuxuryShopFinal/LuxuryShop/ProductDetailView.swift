//
//  ProductDetailView.swift
//  LuxuryShop
//
//  Created by michael.wang on 2019/10/12.
//  Copyright © 2019 Michael Wang. All rights reserved.
//

import SwiftUI

struct ProductDetailView: View {
    var product: Product
    @Binding var wishlist: [String]
    
    var body: some View {
        VStack(alignment: .center, spacing: 10) {
            Image(product.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
            
            HStack {
                Text(product.name)
                Image(systemName: wishlist.contains(product.id) ? "star.fill" : "star")
                    .padding()
                    .onTapGesture {
                        if self.wishlist.contains(self.product.id) {
                            self.wishlist.removeAll(where: { $0 == self.product.id })
                        } else {
                            self.wishlist.append(self.product.id)
                        }
                }
            }
            
            Text(String(format: "$%.2f", product.price))
            
            Spacer()
        }.padding()
    }
}

struct ProductDetailView_Previews: PreviewProvider {
    @State static var wishlist: [String] = []
    
    static var previews: some View {
        ProductDetailView(product: Product.nikeShoes[0], wishlist: $wishlist)
    }
}
