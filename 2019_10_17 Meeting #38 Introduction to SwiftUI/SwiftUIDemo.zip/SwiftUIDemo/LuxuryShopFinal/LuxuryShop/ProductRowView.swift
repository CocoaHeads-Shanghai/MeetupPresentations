//
//  ProductRowView.swift
//  LuxuryShop
//
//  Created by michael.wang on 2019/10/12.
//  Copyright © 2019 Michael Wang. All rights reserved.
//

import SwiftUI

struct ProductRowView: View {
    var product: Product
    @Binding var wishlist: [String]
    
    var body: some View {
        HStack(alignment: .top) {
            Image(product.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
            
            VStack(alignment: .leading, spacing: 10) {
                Text(product.name)
                Text(String(format: "$%.2f", product.price))
                
                Spacer()
            }
            
            Spacer()
            Image(systemName: wishlist.contains(product.id) ? "star.fill" : "star")
                .padding()
                .onTapGesture {
                    if self.wishlist.contains(self.product.id) {
                        self.wishlist.removeAll(where: { $0 == self.product.id })
                    } else {
                        self.wishlist.append(self.product.id)
                    }
            }
        }
    }
}

struct ProductRowView_Previews: PreviewProvider {
    @State static var wishlist: [String] = []
    
    static var previews: some View {
        ProductRowView(product: Product.nikeShoes[0], wishlist: $wishlist)
    }
}
