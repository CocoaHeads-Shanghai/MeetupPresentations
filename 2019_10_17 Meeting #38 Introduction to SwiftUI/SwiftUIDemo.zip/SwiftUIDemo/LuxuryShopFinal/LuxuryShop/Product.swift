//
//  Product.swift
//  LuxuryShop
//
//  Created by michael.wang on 2019/10/12.
//  Copyright © 2019 Michael Wang. All rights reserved.
//

import Foundation

struct Product: Identifiable {
    var id: String
    var name: String
    var brand: String
    var price: Double
    var imageName: String
    var isFavorite = false
}

extension Product {
    static var nikeShoes = [
        Product(id: "13678429", name: "Nike x Off-White The 10: Nike Zoom Fly运动鞋", brand: "NIKE", price: 479, imageName: "13678429"),
        Product(id: "13556333", name: "Nike x Off-White Zoom Fly运动鞋", brand: "NIKE", price: 360, imageName: "13556333"),
        Product(id: "13031484", name: "Nike x Off-White Vapormax FK运动鞋", brand: "NIKE", price: 799, imageName: "13031484"),
        Product(id: "13555690", name: "Nike x Off-White Blazer Mid板鞋", brand: "NIKE", price: 900, imageName: "13555690"),
        Product(id: "13157604", name: "Nike x Off-White The 10: Air Vapormax Flyknit运动鞋", brand: "NIKE", price: 899, imageName: "13157604"),
        Product(id: "13157780", name: "Nike x Off-White The 10: Blazer Mid运动鞋", brand: "NIKE", price: 1149, imageName: "13157780"),
        Product(id: "14217638", name: "Nike x Off-White Terra Kiger 5运动鞋", brand: "NIKE", price: 300, imageName: "14217638"),
        Product(id: "13684136", name: "Nike x Off-White The 10: Air Max 97 OG运动鞋", brand: "NIKE", price: 1295, imageName: "13684136")
    ]
}
