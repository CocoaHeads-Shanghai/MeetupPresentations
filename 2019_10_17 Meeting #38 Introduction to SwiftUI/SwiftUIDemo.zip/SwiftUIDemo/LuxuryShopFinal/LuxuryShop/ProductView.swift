//
//  ProductView.swift
//  LuxuryShop
//
//  Created by michael.wang on 2019/10/12.
//  Copyright © 2019 Michael Wang. All rights reserved.
//

import SwiftUI

struct ProductView: View {
    private var products = Product.nikeShoes
    @State var wishlist: [String] = []

    var body: some View {
        NavigationView {

            List(products) { product in
                NavigationLink(destination: ProductDetailView(product: product, wishlist: self.$wishlist)) {
                    ProductRowView(product: product, wishlist: self.$wishlist)
                }

            }.navigationBarTitle("Nike")
        }
    }
}

struct ProductView_Previews: PreviewProvider {
    static var previews: some View {
        ProductView()
    }
}
