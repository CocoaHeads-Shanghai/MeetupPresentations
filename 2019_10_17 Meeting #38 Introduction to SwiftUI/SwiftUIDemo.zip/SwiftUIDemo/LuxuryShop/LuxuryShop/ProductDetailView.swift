//
//  ProductDetailView.swift
//  LuxuryShop
//
//  Created by michael.wang on 2019/10/12.
//  Copyright © 2019 Michael Wang. All rights reserved.
//

import SwiftUI

struct ProductDetailView: View {
    var product: Product
    
    var body: some View {
        VStack(alignment: .center, spacing: 10) {
            Image(product.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
            
            Text(product.name)
            Text(String(format: "$%.2f", product.price))
        }.padding()
    }
}

struct ProductDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ProductDetailView(product: Product.nikeShoes[0])
    }
}
