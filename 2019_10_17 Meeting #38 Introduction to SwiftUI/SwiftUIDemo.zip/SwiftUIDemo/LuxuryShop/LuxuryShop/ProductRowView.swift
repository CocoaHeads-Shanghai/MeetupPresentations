//
//  ProductRowView.swift
//  LuxuryShop
//
//  Created by michael.wang on 2019/10/12.
//  Copyright © 2019 Michael Wang. All rights reserved.
//

import SwiftUI

struct ProductRowView: View {
    var product: Product
    
    var body: some View {
        HStack(alignment: .top) {
            Image(product.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
            
            VStack(alignment: .leading, spacing: 10) {
                Text(product.name)
                Text(String(format: "$%.2f", product.price))
                
                Spacer()
            }
        }
    }
}

struct ProductRowView_Previews: PreviewProvider {
    static var previews: some View {
        ProductRowView(product: Product.nikeShoes[0])
    }
}
